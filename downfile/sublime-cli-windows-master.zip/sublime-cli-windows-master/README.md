# sublime-cli-windows
Open Sublime Text 3 From the Command Line by type subl

# Notice
	for it work install.bat will do following thing in your system
	1. place a file C:\env.bat
	2. change registry [HKEY_CURRENT_USER\Software\Microsoft\Command Processor\AutoRun]

# Install
	Step 1. Download install.bat
	Step 2. Right click on install.bat -> click "run as administrator"

# Usage

	In Command line type "subl" to open your Sublime Text.

# Uninstall

	Step 1. Download uninstall.bat
	Step 2. Right click on uninstall.bat -> click "run as administrator"